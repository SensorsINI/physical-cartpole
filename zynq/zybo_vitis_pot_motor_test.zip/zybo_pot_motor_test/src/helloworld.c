/******************************************************************************
 *
 * Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Use of the Software is limited solely to applications:
 * (a) running on a Xilinx device, or
 * (b) that interact with a Xilinx device through a bus or interconnect.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 * OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * Except as contained in this notice, the name of the Xilinx shall not be used
 * in advertising or otherwise to promote the sale, use or other dealings in
 * this Software without prior written authorization from Xilinx.
 *
 ******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

/************ Include Files ************/

#include "MotorFeedback.h"
#include "PmodDHB1.h"
#include "PWM.h"
#include "sleep.h"
#include "xil_cache.h"
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xadcps.h"

/************ Macro Definitions ************/

#define GPIO_BASEADDR     XPAR_PMODDHB1_0_AXI_LITE_GPIO_BASEADDR
#define PWM_BASEADDR      XPAR_PMODDHB1_0_PWM_AXI_BASEADDR
#define MOTOR_FB_BASEADDR XPAR_PMODDHB1_0_MOTOR_FB_AXI_BASEADDR

#ifdef __MICROBLAZE__
#define CLK_FREQ XPAR_CPU_M_AXI_DP_FREQ_HZ
#else
#define CLK_FREQ 50000000 // FCLK0 frequency not found in xparameters.h
#endif

#define PWM_PER              2
#define SENSOR_EDGES_PER_REV 4
#define GEARBOX_RATIO        48

#define XADC_DEVICE_ID XPAR_PS7_XADC_0_DEVICE_ID

/************ Function Prototypes ************/

void drive(int16_t sensor_edges);

/************ Global Variables ************/

PmodDHB1 pmodDHB1;
MotorFeedback motorFeedback;

/************ Function Definitions ************/

int main(void) {

	// Init the XADC
	XAdcPs XADC_Driver_Instance;
	XAdcPs_Config* cfg = XAdcPs_LookupConfig( XADC_DEVICE_ID);
	if (cfg == NULL) {
		printf("Config Lookup Failed!");
		//return;
	}
	XAdcPs_CfgInitialize(&XADC_Driver_Instance, cfg, cfg->BaseAddress);
	XAdcPs_SetSequencerMode(&XADC_Driver_Instance, XADCPS_SEQ_MODE_SINGCHAN);
	XAdcPs_SetSequencerMode(&XADC_Driver_Instance, XADCPS_SEQ_MODE_SAFE);
	XAdcPs_SetSeqChEnables(&XADC_Driver_Instance, XADCPS_SEQ_CH_VPVN | XADCPS_SEQ_CH_AUX15);
	XAdcPs_SetSeqInputMode(&XADC_Driver_Instance, XADCPS_SEQ_CH_AUX15);
	XAdcPs_SetAvg(&XADC_Driver_Instance, XADCPS_AVG_16_SAMPLES);
	//Single Channel
	XAdcPs_SetSequencerMode(&XADC_Driver_Instance, XADCPS_SEQ_MODE_SINGCHAN);
	XAdcPs_SetSingleChParams(&XADC_Driver_Instance, XADCPS_CH_AUX_MAX, FALSE, FALSE, FALSE);

	init_platform();

	// Init the H-Bridge controller

	DHB1_begin(&pmodDHB1, GPIO_BASEADDR, PWM_BASEADDR, CLK_FREQ, PWM_PER);
	MotorFeedback_init(&motorFeedback, MOTOR_FB_BASEADDR, CLK_FREQ, SENSOR_EDGES_PER_REV, GEARBOX_RATIO);
	DHB1_motorDisable(&pmodDHB1);

	printf("Hello. This is a software to test the Potentiometer and the H-Bridge controllers.\n\r");

	// Set motor parameters
	int PWM_DUTY = 75, MOTOR_DIR = 0, NUM_STEPS = 1000; // PWM_DUTY [0:100], MOTOR_DIR [0-1]
	DHB1_setMotorSpeeds(&pmodDHB1, PWM_DUTY, 0);
	DHB1_setDirs(&pmodDHB1, 0, 0);
	MotorFeedback_clearPosCounter(&motorFeedback);
	printf("Motor PWM duty-cycle: %d. Motor direction: %d", PWM_DUTY, MOTOR_DIR);

	while(1){
		printf("Moving %d steps to %d direction at %d pwm duty-cycle.\n\r", NUM_STEPS, MOTOR_DIR, PWM_DUTY);
		drive(NUM_STEPS);
		print("Motor stopped.\n\r");

		print("Reading the potentiometer using the XADC.\n\r");
		u16 volt_raw = XAdcPs_GetAdcData (& XADC_Driver_Instance , XADCPS_CH_AUX_MAX);
		//Transform the raw volt data
		float volt_f = XAdcPs_RawToVoltage(volt_raw);
		volt_f = volt_f*10.0;
		//Transform the data into the degree indicator
		float degree = volt_f/27.5*360;
		//Display the data on the serial terminal
		printf("Voltage: %f\n",degree);

		MOTOR_DIR = !MOTOR_DIR;
		DHB1_setDirs(&pmodDHB1, 0, 0);
		usleep(6);
		printf("Moving %d steps to %d direction at %d pwm duty-cycle.\n\r", NUM_STEPS, MOTOR_DIR, PWM_DUTY);
		drive(NUM_STEPS);
		print("Motor stopped.\n\r");

		printf("Reading the potentiometer using the XADC.\n\r");
		volt_raw = XAdcPs_GetAdcData (& XADC_Driver_Instance , XADCPS_CH_AUX_MAX);
		//Transform the raw volt data
		volt_f = XAdcPs_RawToVoltage(volt_raw);
		volt_f = volt_f*10.0;
		//Transform the data into the degree indicator
		degree = volt_f/27.5*360;
		//Display the data on the serial terminal
		printf("Voltage: %f\n",degree);
	}

	cleanup_platform();
	return 0;
}


void drive(int16_t sensor_edges) {
	DHB1_motorEnable(&pmodDHB1);
	int16_t dist = MotorFeedback_getDistanceTraveled(&motorFeedback);
	while (dist < sensor_edges) {
		dist = MotorFeedback_getDistanceTraveled(&motorFeedback);
	}
	MotorFeedback_clearPosCounter(&motorFeedback);
	DHB1_motorDisable(&pmodDHB1);
}

